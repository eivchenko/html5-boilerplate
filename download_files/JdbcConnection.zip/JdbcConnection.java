import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcConnection {
  static Connection conn;

  public static void main(String[] args) {
    String driver = "com.mysql.jdbc.Driver";
    String connectionURL = "jdbc:mysql://127.0.0.1:3306/sample";
    try {
      Class.forName(driver);
    } catch (java.lang.ClassNotFoundException e) {
      e.printStackTrace();
    }
    try {
      conn = DriverManager.getConnection(connectionURL);
      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT * FROM NONEXISTINGTABLE");
      rs.next();
      rs.close();
    } catch (SQLException sx) {
      for (Throwable e : sx) {
        System.err.println("Error encountered: " + e);
      }
    }
  }
}