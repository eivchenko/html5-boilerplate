#!/bin/env python

import MySQLdb

def main():

    db = MySQLdb.connect(host="localhost", user="john", passwd="megajonhy", db="jonhydb")
    cursor = db.cursor()
    cursor.execute("SELECT * FROM YOUR_TABLE_NAME")

    for row in cursor.fetchall():
        print row[0]

if __name__ == '__main__':
    main()