#!/bin/env python

with open("filename.txt") as myfile:
    myfile.write("line1")
    myfile.write("line2")